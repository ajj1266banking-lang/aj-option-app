
import streamlit as st
import pandas as pd
from datetime import date

st.set_page_config(page_title="Trading App", layout="wide")
st.title("My Trading App")

if "trades" not in st.session_state:
    st.session_state.trades = []

st.header("Add Trade")
with st.form("trade"):
    d = st.date_input("Date", value=date.today())
    symbol = st.text_input("Symbol")
    strategy = st.selectbox(
        "Strategy",
        ["Call", "Put", "Credit Spread", "Calendar", "Diagonal", "Butterfly"]
    )
    pnl = st.number_input("P/L ($)", value=0.0)
    submit = st.form_submit_button("Save")

    if submit:
        st.session_state.trades.append(
            {"date": d, "symbol": symbol, "strategy": strategy, "pnl": pnl}
        )
        st.success("Trade added")

st.divider()
st.header("Trades")

if st.session_state.trades:
    df = pd.DataFrame(st.session_state.trades)
    st.dataframe(df)
    st.metric("Total P/L", f"${df.pnl.sum():,.2f}")
else:
    st.info("No trades yet")
